group:
  Alexandre Aparecido Scrocaro Junior RA: 2135485,
  Pedro Klayn RA:2171490

client and server has its own README
